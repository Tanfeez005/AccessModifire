package com.assignment.publicaccess;

public class PublicClass {
	public void publicMethod(){
		System.out.println("This is public method");
	}
	

	public static void main(String[] args) {
		
		

	}
}

