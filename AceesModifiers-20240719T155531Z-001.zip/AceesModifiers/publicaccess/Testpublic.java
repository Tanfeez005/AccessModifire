package com.assignment.publicaccess;

public class Testpublic {

	public static void main(String[] args) {
		PublicClass p=new PublicClass();
		p.publicMethod();

	}

}
