package com.assignment.protectedaccess;

public class Testprotected {

	public static void main(String[] args) {
		ProtectedClass b=new ProtectedClass();
		b.protectedMethod();

	}

}
