package com.assignment.protectedaccess;

public class SubProtectedClass extends ProtectedClass {
	
	

	public static void main(String[] args) {
		ProtectedClass A=new ProtectedClass();
		A.protectedMethod(); 

	}

}
