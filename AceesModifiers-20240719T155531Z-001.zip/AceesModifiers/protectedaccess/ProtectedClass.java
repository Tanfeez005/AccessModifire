package com.assignment.protectedaccess;

 public class ProtectedClass {
	
	protected void protectedMethod(){
		System.out.println("This is a protected method");
		
	}
		

	public static void main(String[] args) {
		

	}

   }

