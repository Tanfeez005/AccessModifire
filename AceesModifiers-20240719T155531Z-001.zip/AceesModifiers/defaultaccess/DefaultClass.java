package com.assignment.defaultaccess;

 class DefaultClass {
	void DefaultMethod() {
		System.out.println("This is a default method");
	}

	public static void main(String[] args) {
		//DefaultClass D=new DefaultClass();
		//D.DefaultMethod();

	}

}
