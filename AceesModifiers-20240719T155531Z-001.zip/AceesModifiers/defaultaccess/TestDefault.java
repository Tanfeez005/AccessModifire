package com.assignment.defaultaccess;

public class TestDefault {

	public static void main(String[] args) {
		DefaultClass D=new DefaultClass();
		D.DefaultMethod();

	}

}
